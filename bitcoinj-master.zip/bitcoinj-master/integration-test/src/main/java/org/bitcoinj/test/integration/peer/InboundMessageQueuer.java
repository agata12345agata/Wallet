/*
 * Copyright by the original author or authors.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.bitcoinj.test.integration.peer;

import org.bitcoinj.core.BitcoinSerializer;
import org.bitcoinj.core.BloomFilter;
import org.bitcoinj.core.Message;
import org.bitcoinj.core.Peer;
import org.bitcoinj.core.PeerAddress;
import org.bitcoinj.core.PeerSocketHandler;
import org.bitcoinj.core.Ping;
import org.jspecify.annotations.Nullable;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * An extension of {@link PeerSocketHandler} that keeps inbound messages in a queue for later processing
 */
public abstract class InboundMessageQueuer extends PeerSocketHandler {
    public final BlockingQueue<Message> inboundMessages = new ArrayBlockingQueue<>(1000);
    /** Map (by nonce) of sent pings waiting for response */
    public final Map<Long, CompletableFuture<Void>> mapPingFutures = new ConcurrentHashMap<>();

    @Nullable public Peer peer;
    @Nullable private BloomFilter lastReceivedFilter;
    private final PeerAddress peerAddress;

    protected InboundMessageQueuer(BitcoinSerializer serializer) {
        super(serializer);
        peerAddress = PeerAddress.simple(new InetSocketAddress(InetAddress.getLoopbackAddress(), 2000));
    }

    @Override
    public PeerAddress getAddress() {
        return peerAddress;
    }

    public Message nextMessage() {
        return inboundMessages.poll();
    }

    public Message nextMessageBlocking() throws InterruptedException {
        return inboundMessages.take();
    }

    @Nullable
    public BloomFilter lastReceivedFilter() {
        return lastReceivedFilter;
    }

    @Override
    protected void processMessage(Message m) {
        if (m instanceof Ping) {
            CompletableFuture<Void> future = mapPingFutures.get(((Ping) m).nonce());
            if (future != null) {
                future.complete(null);
                return;
            }
        }
        if (m instanceof BloomFilter) {
            lastReceivedFilter = (BloomFilter) m;
        }
        inboundMessages.offer(m);
    }
}
