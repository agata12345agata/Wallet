/*
 * Copyright 2011 Google Inc.
 * Copyright 2015 Andreas Schildbach
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.bitcoinj.core;

import org.bitcoinj.base.Sha256Hash;
import org.bitcoinj.base.internal.ByteUtils;
import org.bitcoinj.crypto.ECKey;
import org.bitcoinj.script.ScriptException;
import org.bitcoinj.wallet.KeyBag;
import org.bitcoinj.wallet.RedeemData;

import org.jspecify.annotations.Nullable;
import java.nio.BufferOverflowException;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.util.Objects;

import static org.bitcoinj.base.internal.Preconditions.checkArgument;
import static org.bitcoinj.base.internal.Preconditions.checkState;

/**
 * <p>This message is a reference or pointer to an output of a different transaction.</p>
 * 
 * <p>Instances of this class are not safe for use by multiple threads.</p>
 */
public class TransactionOutPoint {
    public static final int BYTES = 36;

    /** Special outpoint that normally marks a coinbase input. It's also used as a test dummy. */
    public static final TransactionOutPoint UNCONNECTED =
            TransactionOutPoint.of(Sha256Hash.ZERO_HASH, ByteUtils.MAX_UNSIGNED_INTEGER);

    /** Hash of the transaction to which we refer. */
    private final Sha256Hash hash;
    /** Which output of that transaction we are talking about. */
    private final long index;

    // `fromTx` and `connectedOutput` can both be `null`, but they can't both be non-`null`.

    // This is not part of bitcoin serialization. It points to the connected transaction.
    @Nullable
    private final Transaction fromTx;

    // The connected output.
    @Nullable
    private final TransactionOutput connectedOutput;

    /**
     * Deserialize this transaction outpoint from a given payload.
     *
     * @param payload payload to deserialize from
     * @return read transaction outpoint
     * @throws BufferUnderflowException if the read message extends beyond the remaining bytes of the payload
     */
    public static TransactionOutPoint read(ByteBuffer payload) throws BufferUnderflowException, ProtocolException {
        Sha256Hash hash = Sha256Hash.read(payload);
        long index = ByteUtils.readUint32(payload);
        return TransactionOutPoint.of(hash, index);
    }

    /** @deprecated use {@link TransactionOutPoint#from(Transaction, long)} */
    @Deprecated
    public TransactionOutPoint(long index, Transaction fromTx) {
        this(fromTx.getTxId(), index, fromTx, null);
    }

    /**
     * @deprecated use {@link TransactionOutPoint#of(Sha256Hash, long)}
     */
    @Deprecated
    public TransactionOutPoint(long index, Sha256Hash hash) {
        this(hash, index, null, null);
    }

    private TransactionOutPoint(Sha256Hash hash, long index) {
        this(hash, index, null, null);
    }

    /** @deprecated use {@link TransactionOutPoint#from(TransactionOutput)} */
    @Deprecated
    public TransactionOutPoint(TransactionOutput connectedOutput) {
        this(connectedOutput.getParentTransactionHash(), connectedOutput.getIndex(), null, connectedOutput);
    }

    /**
     * Create a simple {@code TransactionOutPoint} with only {@code txid} and {@code index}.
     * @param hash Transaction ID of the referenced transaction
     * @param index Output index of the referenced output
     * @return a new transaction outpoint
     */
    public static TransactionOutPoint of(Sha256Hash hash, long index) {
        return new TransactionOutPoint(hash, index);
    }

    /**
     * Create a {@code TransactionOutPoint} <i>from</i> an existing {@link Transaction}.
     * @param fromTx transaction the new outpoint will reference (and be "connected to")
     * @param index index of the transaction output the new outpoint will reference
     * @return a new transaction outpoint
     */
    public static TransactionOutPoint from(Transaction fromTx, long index) {
        return new TransactionOutPoint (fromTx.getTxId(), index, fromTx, null);
    }

    /**
     * Create a {@code TransactionOutPoint} <i>from</i> an existing {@link TransactionOutput}.
     * @param connectedOutput transaction output the new outpoint will reference (and be "connected to")
     * @return a new transaction outpoint
     */
    public static TransactionOutPoint from(TransactionOutput connectedOutput) {
        return new TransactionOutPoint(connectedOutput.getParentTransactionHash(), connectedOutput.getIndex(), null,
                connectedOutput);
    }

    private TransactionOutPoint(Sha256Hash hash, long index, @Nullable Transaction fromTx,
                                @Nullable TransactionOutput connectedOutput) {
        this.hash = Objects.requireNonNull(hash);
        checkArgument(index >= 0 && index <= ByteUtils.MAX_UNSIGNED_INTEGER, () ->
                "index out of range: " + index);
        this.index = index;
        if (fromTx != null) {
            TransactionOutput outputFromTx = fromTx.getOutput(index);
            Objects.requireNonNull(outputFromTx);
            checkArgument(connectedOutput == null, () -> "Both fromTx and connectedOutput are non-null");
        }
        this.fromTx = fromTx;
        this.connectedOutput = connectedOutput;
    }

    /**
     * Write this transaction outpoint into the given buffer.
     *
     * @param buf buffer to write into
     * @return the buffer
     * @throws BufferOverflowException if the outpoint doesn't fit the remaining buffer
     */
    public ByteBuffer write(ByteBuffer buf) throws BufferOverflowException {
        hash.write(buf);
        ByteUtils.writeInt32LE(index, buf);
        return buf;
    }

    /**
     * Allocates a byte array and writes this transaction outpoint into it.
     *
     * @return byte array containing the transaction outpoint
     */
    public byte[] serialize() {
        return write(ByteBuffer.allocate(BYTES)).array();
    }

    /**
     * An outpoint is a part of a transaction input that points to the output of another transaction. If we have both
     * sides in memory, and they have been linked together, this returns a pointer to the connected output, or {@code
     * null} if we don't have the output. In the latter case, {@link #hash()} and {@link #index()} could be used to
     * acquire the output elsewhere.
     *
     * @return output this outpoint points to, or {@code null} if we don't have the output
     */
    @Nullable
    public TransactionOutput getConnectedOutput() {
        return (fromTx != null) ? fromTx.getOutput(index) : connectedOutput;
    }

    /**
     * Return the connected {@link Transaction} if available.
     * @return connected transaction or {@code null} if not available
     */
    @Nullable
    public Transaction getFromTx() {
        return fromTx;
    }

    /**
     * Returns the pubkey script from the connected output.
     * @throws java.lang.NullPointerException if there is no connected output.
     * @deprecated Use {@link #getConnectedOutput()}
     */
    @Deprecated
    public byte[] getConnectedPubKeyScript() {
        byte[] result = Objects.requireNonNull(getConnectedOutput()).getScriptBytes();
        checkState(result.length > 0);
        return result;
    }

    /**
     * Returns the ECKey identified in the connected output, for either P2PKH, P2WPKH or P2PK scripts.
     * For P2SH scripts you can use {@link KeyBag#getConnectedRedeemData(TransactionOutPoint)} and then get the
     * key from RedeemData.
     * If the script form cannot be understood, throws ScriptException.
     *
     * @return an ECKey or null if the connected key cannot be found in the wallet.
     * @deprecated Use {@link KeyBag#getConnectedKey(TransactionOutPoint)}
     */
    @Deprecated
    @Nullable
    public ECKey getConnectedKey(KeyBag keyBag) throws ScriptException {
        return keyBag.getConnectedKey(this);
    }

    /**
     * Returns the RedeemData identified in the connected output, for either P2PKH, P2WPKH, P2PK
     * or P2SH scripts.
     * If the script forms cannot be understood, throws ScriptException.
     *
     * @return a RedeemData or null if the connected data cannot be found in the wallet.
     * @deprecated Use {@link KeyBag#getConnectedRedeemData(TransactionOutPoint)}
     */
    @Deprecated
    @Nullable
    public RedeemData getConnectedRedeemData(KeyBag keyBag) throws ScriptException {
        return keyBag.getConnectedRedeemData(this);
    }

    /**
     * Returns a copy of this outpoint, but without either {@code fromTx} or {@code connectedOutput}.
     * @return outpoint with no connections
     */
    public TransactionOutPoint disconnectOutput() {
        return new TransactionOutPoint(hash, index, null, null);
    }

    /**
     * Returns a copy of this outpoint, but with the provided transaction as fromTx.
     * @param transaction transaction to set as fromTx
     * @return outpoint with fromTx set
     */
    public TransactionOutPoint connectTransaction(Transaction transaction) {
        return new TransactionOutPoint(hash, index, Objects.requireNonNull(transaction), null);
    }

    /**
     * Returns a copy of this outpoint, but with fromTx removed.
     * @return outpoint with removed fromTx
     * @deprecated use {@link #disconnectOutput()}
     */
    @Deprecated
    public TransactionOutPoint disconnectTransaction() {
        return disconnectOutput();
    }

    @Override
    public String toString() {
        return hash + ":" + index;
    }

    /**
     * Returns the hash of the transaction this outpoint references/spends/is connected to.
     */
    public Sha256Hash hash() {
        return hash;
    }

    /**
     * @return the index of this outpoint
     */
    public long index() {
        return index;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TransactionOutPoint other = (TransactionOutPoint) o;
        return index == other.index && hash.equals(other.hash);
    }

    @Override
    public int hashCode() {
        return Objects.hash(index, hash);
    }
}
